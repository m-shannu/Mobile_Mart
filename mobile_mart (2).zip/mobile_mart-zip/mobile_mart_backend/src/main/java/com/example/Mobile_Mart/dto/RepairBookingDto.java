package com.example.Mobile_Mart.dto;

import lombok.Data;

@Data
public class RepairBookingDto {
    private Long userId;
    private Long slotId;
    private String itemName;
    private String issueDescription;
}
