package com.example.Mobile_Mart.config;

import com.example.Mobile_Mart.model.Role;
import com.example.Mobile_Mart.model.User;
import com.example.Mobile_Mart.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class AdminInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        boolean adminExists = userRepository.existsByRole(Role.ADMIN);
        if (!adminExists) {
            User admin = new User();
            admin.setUsername("Shanmukh");
            admin.setEmail("shanmukhmadicherla@gmail.com");
            admin.setPassword(passwordEncoder.encode("Shannu@7"));
            admin.setRole(Role.ADMIN);
            userRepository.save(admin);
            System.out.println("✅ Admin created with email: shanmukhmadicherla@gmail.com and password: Shannu@7");
        }
    }
}
