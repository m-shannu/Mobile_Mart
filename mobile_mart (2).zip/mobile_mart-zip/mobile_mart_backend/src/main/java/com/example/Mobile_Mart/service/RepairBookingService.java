package com.example.Mobile_Mart.service;

import com.example.Mobile_Mart.dto.RepairBookingDto;
import com.example.Mobile_Mart.model.*;
import com.example.Mobile_Mart.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class RepairBookingService {

    private final RepairBookingRepository bookingRepository;
    private final AvailableSlotRepository slotRepository;
    private final UserRepository userRepository;

    public RepairBooking bookRepair(RepairBookingDto dto) {
        User user = userRepository.findById(dto.getUserId()).orElseThrow();
        AvailableSlot slot = slotRepository.findById(dto.getSlotId()).orElseThrow();

        if (slot.isBooked()) {
            throw new IllegalStateException("Slot already booked");
        }

        RepairBooking booking = new RepairBooking();
        booking.setUser(user);
        booking.setSlot(slot);
        booking.setItemName(dto.getItemName());
        booking.setIssueDescription(dto.getIssueDescription());

        slot.setBooked(true);
        slotRepository.save(slot);

        return bookingRepository.save(booking);
    }

    public List<RepairBooking> getBookingsByUser(Long userId) {
        User user = userRepository.findById(userId).orElseThrow();
        return bookingRepository.findByUser(user);
    }

    public List<RepairBooking> getAllBookings() {
        return bookingRepository.findAll();
    }
}
