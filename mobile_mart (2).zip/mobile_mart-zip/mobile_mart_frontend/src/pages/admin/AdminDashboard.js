import React from 'react';
import { Link } from 'react-router-dom';
import './Admin.css';

function AdminDashboard() {
  return (
    <div className="admin-dashboard">
      <h2>Admin Dashboard</h2>
      <ul>
        <li><Link to="/admin/categories">Manage Categories</Link></li>
        <li><Link to="/admin/items">Manage Items</Link></li>
        <li><Link to="/admin/slots">Manage Slots</Link></li>
      </ul>
    </div>
  );
}

export default AdminDashboard;
