package com.example.Mobile_Mart.model;

public enum Role {
	ADMIN,
	USER
}
