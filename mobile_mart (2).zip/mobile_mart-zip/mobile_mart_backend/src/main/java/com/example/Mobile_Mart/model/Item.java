package com.example.Mobile_Mart.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "items")
public class Item {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "category_id", nullable = false)
    private Category category;

    private String name;
    private String brand;
    private String model;
    private String color;
    private String imei;
    private String warranty;
    private Integer batteryCapacity;
    private Integer wattage;
    private int stockQuantity;
    private double price;
    private double discount;
    private boolean available;

    @Lob
    @Column(columnDefinition = "LONGBLOB")
    private byte[] image;
}
