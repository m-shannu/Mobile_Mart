import React, { useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import "./Auth.css";

function ForgotPassword() {
  const [form, setForm] = useState({ email: "", newPassword: "" });
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage("");
    setError("");

    try {
      const res = await axios.post(
        `${process.env.REACT_APP_API_BASE_URL}/auth/reset-password`,
        form
      );
      setMessage(res.data);
    } catch (err) {
      setError(err.response?.data || "Password reset failed.");
    }
  };

  return (
    <div className="auth-wrapper">
      <div className="auth-form">
        <h2 className="text-center text-primary mb-4">Reset Password</h2>

        {error && <div className="alert alert-danger">{error}</div>}
        {message && <div className="alert alert-success">{message}</div>}

        <form onSubmit={handleSubmit}>
          <div className="form-group mb-3">
            <label>Registered Email</label>
            <input
              type="email"
              name="email"
              className="form-control"
              required
              value={form.email}
              onChange={handleChange}
            />
          </div>

          <div className="form-group mb-4">
            <label>New Password</label>
            <input
              type="password"
              name="newPassword"
              className="form-control"
              required
              minLength={6}
              value={form.newPassword}
              onChange={handleChange}
            />
          </div>

          <button type="submit" className="btn btn-primary w-100">
            Reset Password
          </button>
        </form>

        <p className="text-center mt-3">
          <Link to="/login" className="text-primary">
            Back to Login
          </Link>
        </p>
      </div>
    </div>
  );
}

export default ForgotPassword;
