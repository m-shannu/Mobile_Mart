package com.example.Mobile_Mart.controller;

import com.example.Mobile_Mart.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/admin")
@RequiredArgsConstructor
public class AdminController {

    private final UserRepository userRepository;
    private final ItemRepository itemRepository;
    private final CategoryRepository categoryRepository;
    private final RepairBookingRepository repairBookingRepository;
    private final AvailableSlotRepository availableSlotRepository;

    @GetMapping("/dashboard")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Map<String, Object>> getDashboardStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalUsers", userRepository.count());
        stats.put("totalItems", itemRepository.count());
        stats.put("totalCategories", categoryRepository.count());
        stats.put("totalRepairBookings", repairBookingRepository.count());
        stats.put("availableSlots", availableSlotRepository.findByBookedFalse().size());
        return ResponseEntity.ok(stats);
    }
}
