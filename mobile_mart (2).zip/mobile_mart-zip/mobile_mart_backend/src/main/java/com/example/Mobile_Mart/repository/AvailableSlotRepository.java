package com.example.Mobile_Mart.repository;

import com.example.Mobile_Mart.model.AvailableSlot;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AvailableSlotRepository extends JpaRepository<AvailableSlot, Long> {
    List<AvailableSlot> findByBookedFalse();
}
