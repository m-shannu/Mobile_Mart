import React, { useState, useEffect } from "react";
import axios from "axios";
import "./Admin.css";

function CategoryManagement() {
  const [name, setName] = useState("");
  const [categories, setCategories] = useState([]);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const token = localStorage.getItem("token");

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const res = await axios.get(
          `${process.env.REACT_APP_API_BASE_URL}/admin/categories/all`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setCategories(res.data);
      } catch (err) {
        console.error(err);
        setError("Failed to load categories");
      }
    };

    fetchCategories();
  }, [token]);

  const handleAdd = async (e) => {
    e.preventDefault();
    setError("");
    setMessage("");

    try {
      await axios.post(
        `${process.env.REACT_APP_API_BASE_URL}/admin/categories/add`,
        { name },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setMessage("Category added successfully");
      setName("");

      // Refetch after adding
      const res = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/admin/categories/all`, {
  headers: {
    Authorization: `Bearer ${token}`,
  },
});

      setCategories(res.data);
    } catch (err) {
      setError(err.response?.data || "Failed to add category");
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(
        `${process.env.REACT_APP_API_BASE_URL}/admin/categories/delete/${id}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      // Refetch after deletion
      const res = await axios.get(
        `${process.env.REACT_APP_API_BASE_URL}/admin/categories/all`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setCategories(res.data);
    } catch (err) {
      console.error(err);
      setError("Failed to delete category");
    }
  };

  return (
    <div className="admin-container">
      <h2 className="admin-title">Category Management</h2>

      <form onSubmit={handleAdd} className="admin-form">
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="admin-input"
          placeholder="Enter category name"
          required
        />
        <button type="submit" className="admin-btn">Add Category</button>
      </form>

      {error && <div className="admin-error">{error}</div>}
      {message && <div className="admin-success">{message}</div>}

      <ul className="admin-list">
        {categories.map((cat) => (
          <li key={cat.id} className="admin-list-item">
            {cat.name}
            <button onClick={() => handleDelete(cat.id)} className="admin-delete-btn">Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default CategoryManagement;
