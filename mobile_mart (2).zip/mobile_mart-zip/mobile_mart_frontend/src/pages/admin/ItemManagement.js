import React, { useState, useEffect } from "react";
import axios from "axios";
import "./Admin.css";

function ItemManagement() {
  const [items, setItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [newItem, setNewItem] = useState({
    name: "",
    brand: "",
    model: "",
    price: "",
    stockQuantity: "",
    categoryId: "",
  });
  const [image, setImage] = useState(null);
  const [editMode, setEditMode] = useState(false);
  const [editItemId, setEditItemId] = useState(null);

  const token = localStorage.getItem("token");

  useEffect(() => {
    fetchItems();
    fetchCategories();
  }, []);

  const fetchItems = async () => {
    try {
      const res = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/admin/items`);
      setItems(res.data);
    } catch (err) {
      console.error("Fetch items error:", err);
    }
  };

  const fetchCategories = async () => {
    try {
      const res = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/admin/categories`);
      setCategories(res.data);
    } catch (err) {
      console.error("Fetch categories error:", err);
    }
  };

  const handleInputChange = (e) => {
    setNewItem({ ...newItem, [e.target.name]: e.target.value });
  };

  const handleImageChange = (e) => {
    setImage(e.target.files[0]);
  };

  const resetForm = () => {
    setNewItem({
      name: "",
      brand: "",
      model: "",
      price: "",
      stockQuantity: "",
      categoryId: "",
    });
    setImage(null);
    setEditMode(false);
    setEditItemId(null);
  };

  const handleAddOrUpdateItem = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    Object.keys(newItem).forEach((key) => formData.append(key, newItem[key]));
    if (image) formData.append("image", image);

    try {
      if (editMode) {
        await axios.put(`${process.env.REACT_APP_API_BASE_URL}/admin/items/${editItemId}`, formData, {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "multipart/form-data",
          },
        });
      } else {
        await axios.post(`${process.env.REACT_APP_API_BASE_URL}/admin/items/add`, formData, {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "multipart/form-data",
          },
        });
      }
      fetchItems();
      resetForm();
    } catch (err) {
      console.error("Add/Update item error:", err);
    }
  };

  const handleEditItem = (item) => {
    setNewItem({
      name: item.name,
      brand: item.brand,
      model: item.model,
      price: item.price,
      stockQuantity: item.stockQuantity,
      categoryId: item.category.id,
    });
    setEditMode(true);
    setEditItemId(item.id);
  };

  const handleDeleteItem = async (id) => {
    try {
      await axios.delete(`${process.env.REACT_APP_API_BASE_URL}/admin/items/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      fetchItems();
    } catch (err) {
      console.error("Delete item error:", err);
    }
  };

  return (
    <div className="admin-container">
      <h2>Item Management</h2>

      <form className="admin-form" onSubmit={handleAddOrUpdateItem}>
        <input type="text" name="name" placeholder="Name" value={newItem.name} onChange={handleInputChange} required />
        <input type="text" name="brand" placeholder="Brand" value={newItem.brand} onChange={handleInputChange} required />
        <input type="text" name="model" placeholder="Model" value={newItem.model} onChange={handleInputChange} />
        <input type="number" name="price" placeholder="Price" value={newItem.price} onChange={handleInputChange} required />
        <input type="number" name="stockQuantity" placeholder="Stock" value={newItem.stockQuantity} onChange={handleInputChange} required />

        <select name="categoryId" value={newItem.categoryId} onChange={handleInputChange} required>
          <option value="">Select Category</option>
          {categories.map((cat) => (
            <option key={cat.id} value={cat.id}>{cat.name}</option>
          ))}
        </select>

        <input type="file" accept="image/*" onChange={handleImageChange} />

        <button type="submit">{editMode ? "Update Item" : "Add Item"}</button>
        {editMode && <button type="button" onClick={resetForm} className="cancel-button">Cancel</button>}
      </form>

      <ul className="admin-list">
        {items.map((item) => (
          <li key={item.id} className="admin-item">
            <div><strong>{item.name}</strong> ({item.brand}) - ₹{item.price}</div>
            <div>
              <button onClick={() => handleEditItem(item)} className="btn btn-warning btn-sm me-2">Edit</button>
              <button onClick={() => handleDeleteItem(item.id)} className="btn btn-danger btn-sm">Delete</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ItemManagement;
