import React, { useState } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import "./Auth.css";

function Login() {
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setMessage("");

    try {
      const res = await axios.post(
        `${process.env.REACT_APP_API_BASE_URL}/auth/login`,
        form
      );
      setMessage(res.data);
      setTimeout(() => {
        navigate("/"); // You can change this to dashboard or home later
      }, 1500);
    } catch (err) {
      setError(err.response?.data || "Login failed. Try again.");
    }
  };

  return (
    <div className="auth-wrapper">
      <div className="auth-form">
        <h2 className="text-center text-primary mb-4">User Login</h2>

        {error && <div className="alert alert-danger">{error}</div>}
        {message && <div className="alert alert-success">{message}</div>}

        <form onSubmit={handleSubmit}>
          <div className="form-group mb-3">
            <label>Email:</label>
            <input
              type="email"
              name="email"
              className="form-control"
              required
              value={form.email}
              onChange={handleChange}
            />
          </div>

          <div className="form-group mb-4">
            <label>Password:</label>
            <input
              type="password"
              name="password"
              className="form-control"
              required
              value={form.password}
              onChange={handleChange}
            />
          </div>

          <button type="submit" className="btn btn-primary w-100">
            Login
          </button>
        </form>

        <p className="text-center mt-3">
          Forgot your password?{" "}
          <Link to="/forgot-password" className="text-primary">
            Reset here
          </Link>
        </p>

        <p className="text-center mt-2">
          Don't have an account?{" "}
          <Link to="/signup" className="text-primary">
            Sign up
          </Link>
        </p>
      </div>
    </div>
  );
}

export default Login;
