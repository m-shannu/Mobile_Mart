package com.example.Mobile_Mart.service;

import com.example.Mobile_Mart.model.AvailableSlot;
import com.example.Mobile_Mart.repository.AvailableSlotRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AvailableSlotService {

    private final AvailableSlotRepository slotRepository;

    public AvailableSlot addSlot(AvailableSlot slot) {
        slot.setBooked(false);
        return slotRepository.save(slot);
    }

    public List<AvailableSlot> getAllSlots() {
        return slotRepository.findAll();
    }

    public List<AvailableSlot> getAvailableSlots() {
        return slotRepository.findByBookedFalse();
    }

    public void deleteSlot(Long id) {
        slotRepository.deleteById(id);
    }
}
