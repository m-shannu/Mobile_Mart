package com.example.Mobile_Mart.service;

import com.example.Mobile_Mart.dto.LoginDto;
import com.example.Mobile_Mart.dto.ResetPasswordDto;
import com.example.Mobile_Mart.dto.SignupDto;
import com.example.Mobile_Mart.model.Role;
import com.example.Mobile_Mart.model.User;
import com.example.Mobile_Mart.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final AuthenticationManager authenticationManager;
    private final PasswordEncoder passwordEncoder;

    public String registerUser(SignupDto dto) {
        if (userRepository.existsByEmail(dto.getEmail())) {
            return "Email already in use";
        }

        User user = new User();
        user.setUsername(dto.getUsername());
        user.setEmail(dto.getEmail());
        user.setPassword(passwordEncoder.encode(dto.getPassword()));
        user.setRole(Role.USER); // only user registration allowed

        userRepository.save(user);
        return "User registered successfully";
    }

    public String login(LoginDto dto) {
        Authentication auth = authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(dto.getEmail(), dto.getPassword())
        );

        return auth.isAuthenticated() ? "Login successful" : "Login failed";
    }

    public String resetPassword(ResetPasswordDto dto) {
        return userRepository.findByEmail(dto.getEmail())
            .map(user -> {
                user.setPassword(passwordEncoder.encode(dto.getNewPassword()));
                userRepository.save(user);
                return "Password reset successful";
            })
            .orElse("User not found with the given email");
    }
}
