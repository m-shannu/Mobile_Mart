package com.example.Mobile_Mart.controller;

import com.example.Mobile_Mart.dto.RepairBookingDto;
import com.example.Mobile_Mart.model.RepairBooking;
import com.example.Mobile_Mart.service.RepairBookingService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user/repair")
@RequiredArgsConstructor
public class RepairBookingController {

    private final RepairBookingService repairService;

    @PostMapping("/book")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<RepairBooking> bookRepair(@RequestBody RepairBookingDto dto) {
        return ResponseEntity.ok(repairService.bookRepair(dto));
    }

    @GetMapping("/my/{userId}")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<List<RepairBooking>> getUserBookings(@PathVariable Long userId) {
        return ResponseEntity.ok(repairService.getBookingsByUser(userId));
    }

    @GetMapping("/all")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<RepairBooking>> getAllBookings() {
        return ResponseEntity.ok(repairService.getAllBookings());
    }
}
