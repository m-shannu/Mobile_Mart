package com.example.Mobile_Mart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MobileMartApplication {

	public static void main(String[] args) {
		SpringApplication.run(MobileMartApplication.class, args);
	}

}
