package com.example.Mobile_Mart.dto;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
public class ItemDto {

    private String name;
    private String brand;
    private String model;
    private double price;
    private String imei;
    private String wattage;
    private Long categoryId;
    private MultipartFile image;
}
