import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./Auth.css";

function AdminLogin() {
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setMessage("");

    // Optional: validate admin email before sending request
    if (form.email !== "shanmukhmadicherla@gmail.com") {
      setError("Unauthorized admin email");
      return;
    }

    try {
      const res = await axios.post(
        `${process.env.REACT_APP_API_BASE_URL}/auth/login`,
        form
      );
      setMessage("Admin login successful");
      setTimeout(() => {
        navigate("/admin-dashboard");
 // Change as needed
      }, 1500);
    } catch (err) {
      setError(err.response?.data || "Admin login failed. Try again.");
    }
  };

  return (
    <div className="auth-wrapper">
      <div className="auth-form">
        <h2 className="text-center text-danger mb-4">Admin Login</h2>

        {error && <div className="alert alert-danger">{error}</div>}
        {message && <div className="alert alert-success">{message}</div>}

        <form onSubmit={handleSubmit}>
          <div className="form-group mb-3">
            <label>Email (Admin only):</label>
            <input
              type="email"
              name="email"
              className="form-control"
              required
              value={form.email}
              onChange={handleChange}
            />
          </div>

          <div className="form-group mb-4">
            <label>Password:</label>
            <input
              type="password"
              name="password"
              className="form-control"
              required
              value={form.password}
              onChange={handleChange}
            />
          </div>

          <button type="submit" className="btn btn-danger w-100">
            Login as Admin
          </button>
        </form>
      </div>
    </div>
  );
}

export default AdminLogin;
