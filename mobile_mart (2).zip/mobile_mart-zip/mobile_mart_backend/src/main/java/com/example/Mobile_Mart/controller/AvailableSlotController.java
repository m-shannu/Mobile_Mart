package com.example.Mobile_Mart.controller;

import com.example.Mobile_Mart.model.AvailableSlot;
import com.example.Mobile_Mart.service.AvailableSlotService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin/slots")
@RequiredArgsConstructor
public class AvailableSlotController {

    private final AvailableSlotService slotService;

    @PostMapping("/add")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<AvailableSlot> addSlot(@RequestBody AvailableSlot slot) {
        return ResponseEntity.ok(slotService.addSlot(slot));
    }

    @GetMapping("/all")
    public ResponseEntity<List<AvailableSlot>> getAllSlots() {
        return ResponseEntity.ok(slotService.getAllSlots());
    }

    @GetMapping("/available")
    public ResponseEntity<List<AvailableSlot>> getAvailableSlots() {
        return ResponseEntity.ok(slotService.getAvailableSlots());
    }

    @DeleteMapping("/delete/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> deleteSlot(@PathVariable Long id) {
        slotService.deleteSlot(id);
        return ResponseEntity.ok().build();
    }
}
