import React, { useState } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import "./Auth.css";

function Signup() {
  const [form, setForm] = useState({ username: "", email: "", password: "" });
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setMessage("");

    try {
      const res = await axios.post(
        `${process.env.REACT_APP_API_BASE_URL}/auth/signup`,
        form
      );
      setMessage(res.data);
      setTimeout(() => {
        navigate("/login");
      }, 1500);
    } catch (err) {
      setError(err.response?.data || "Signup failed. Try again.");
    }
  };

  return (
    <div className="auth-wrapper">
      <div className="auth-form">
        <h2 className="text-center text-success mb-4">User Signup</h2>

        {error && <div className="alert alert-danger">{error}</div>}
        {message && <div className="alert alert-success">{message}</div>}

        <form onSubmit={handleSubmit}>
          <div className="form-group mb-3">
            <label>Username:</label>
            <input
              type="text"
              name="username"
              className="form-control"
              required
              value={form.username}
              onChange={handleChange}
            />
          </div>

          <div className="form-group mb-3">
            <label>Email:</label>
            <input
              type="email"
              name="email"
              className="form-control"
              required
              value={form.email}
              onChange={handleChange}
            />
          </div>

          <div className="form-group mb-4">
            <label>Password:</label>
            <input
              type="password"
              name="password"
              className="form-control"
              required
              minLength={6}
              value={form.password}
              onChange={handleChange}
            />
          </div>

          <button type="submit" className="btn btn-success w-100">Sign Up</button>
        </form>

        <p className="text-center mt-3">
          Already have an account? <Link to="/login" className="text-success">Login</Link>
        </p>
      </div>
    </div>
  );
}

export default Signup;
