import React from "react";
import { Routes, Route } from "react-router-dom";

import Signup from "./pages/auth/Signup";
import Login from "./pages/auth/Login";
import AdminLogin from "./pages/auth/AdminLogin";
import ForgotPassword from "./pages/auth/ForgotPassword";
import ItemManagement from "./pages/admin/ItemManagement";
import CategoryManagement from "./pages/admin/CategoryManagement";
import SlotManagement from "./pages/admin/SlotManagement";
import AdminDashboard from "./pages/admin/AdminDashboard";

function App() {
  return (
      <Routes>
        
        <Route path="/admin/items" element={<ItemManagement />} />
        <Route path="/admin/categories" element={<CategoryManagement />} />
        <Route path="/admin/slots" element={<SlotManagement />}/>
        <Route path="/admin-dashboard" element={<AdminDashboard />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/login" element={<Login />} />
        <Route path="/admin-login" element={<AdminLogin />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
      </Routes>
  );
}

export default App;
