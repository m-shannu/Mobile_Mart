package com.example.Mobile_Mart.repository;

import com.example.Mobile_Mart.model.RepairBooking;
import com.example.Mobile_Mart.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RepairBookingRepository extends JpaRepository<RepairBooking, Long> {
    List<RepairBooking> findByUser(User user);
}
