package com.example.Mobile_Mart.service;

import com.example.Mobile_Mart.model.Category;
import com.example.Mobile_Mart.model.Item;
import com.example.Mobile_Mart.repository.CategoryRepository;
import com.example.Mobile_Mart.repository.ItemRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ItemService {

    private final ItemRepository itemRepository;
    private final CategoryRepository categoryRepository;

    public Item addItem(Item item, Long categoryId, MultipartFile image) throws IOException {
        Category category = categoryRepository.findById(categoryId).orElseThrow(() ->
                new IllegalArgumentException("Category not found"));

        if (image != null && !image.isEmpty()) {
            item.setImage(image.getBytes());
        }

        item.setAvailable(true);
        item.setCategory(category);
        return itemRepository.save(item);
    }

    public List<Item> getAllItems() {
        return itemRepository.findAll();
    }

    public Item getItemById(Long id) {
        return itemRepository.findById(id).orElse(null);
    }

    public List<Item> getItemsByCategory(Long categoryId) {
        Category category = categoryRepository.findById(categoryId).orElse(null);
        if (category == null) return List.of();
        return itemRepository.findByCategory(category);
    }

    public List<Item> getAvailableItems() {
        return itemRepository.findByAvailableTrue();
    }

    public void deleteItem(Long id) {
        itemRepository.deleteById(id);
    }

    @Transactional
    public Item updateItem(Long id, Item updatedItem, Long categoryId, MultipartFile image) throws IOException {
        Item existing = itemRepository.findById(id).orElse(null);
        if (existing == null) return null;

        Category category = categoryRepository.findById(categoryId).orElse(null);
        if (category == null) return null;

        existing.setName(updatedItem.getName());
        existing.setBrand(updatedItem.getBrand());
        existing.setModel(updatedItem.getModel());
        existing.setColor(updatedItem.getColor());
        existing.setImei(updatedItem.getImei());
        existing.setWarranty(updatedItem.getWarranty());
        existing.setBatteryCapacity(updatedItem.getBatteryCapacity());
        existing.setWattage(updatedItem.getWattage());
        existing.setStockQuantity(updatedItem.getStockQuantity());
        existing.setPrice(updatedItem.getPrice());
        existing.setDiscount(updatedItem.getDiscount());
        existing.setAvailable(updatedItem.isAvailable());
        existing.setCategory(category);

        if (image != null && !image.isEmpty()) {
            existing.setImage(image.getBytes());
        }

        return itemRepository.save(existing);
    }
}
