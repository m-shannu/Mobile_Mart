import React, { useState, useEffect } from "react";
import axios from "axios";
import "./Admin.css";

function SlotManagement() {
  const [slots, setSlots] = useState([]);
  const [newSlot, setNewSlot] = useState({ date: "", time: "" });

  const token = localStorage.getItem("token");

  useEffect(() => {
    fetchSlots();
  }, []);

  const fetchSlots = async () => {
    try {
      const res = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/admin/slots`);
      setSlots(res.data);
    } catch (err) {
      console.error("Fetch slots error:", err);
    }
  };

  const handleInputChange = (e) => {
    setNewSlot({ ...newSlot, [e.target.name]: e.target.value });
  };

  const handleAddSlot = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`${process.env.REACT_APP_API_BASE_URL}/admin/slots/add`, newSlot, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setNewSlot({ date: "", time: "" });
      fetchSlots();
    } catch (err) {
      console.error("Add slot error:", err);
    }
  };

  const handleDeleteSlot = async (id) => {
    try {
      await axios.delete(`${process.env.REACT_APP_API_BASE_URL}/admin/slots/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      fetchSlots();
    } catch (err) {
      console.error("Delete slot error:", err);
    }
  };

  return (
    <div className="admin-container">
      <h2>Repair Slot Management</h2>

      <form className="admin-form" onSubmit={handleAddSlot}>
        <input type="date" name="date" value={newSlot.date} onChange={handleInputChange} required />
        <input type="time" name="time" value={newSlot.time} onChange={handleInputChange} required />
        <button type="submit">Add Slot</button>
      </form>

      <ul className="admin-list">
        {slots.map((slot) => (
          <li key={slot.id} className="admin-item">
            {slot.date} @ {slot.time} — {slot.booked ? "Booked" : "Available"}
            <button onClick={() => handleDeleteSlot(slot.id)} className="admin-delete-btn">Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default SlotManagement;
